
from hm3u8dl_cli import args,m3u8download,merge
import os


def run():
    args1 = args()
    args2 = args()

    args1.m3u8url = input("请输入视频M3U8：")
    args1.key = input("请输入视频key：")
    args1.title = input("请输入视频名字：")

    args.m3u8url = input("请输入音频M3U8：")
    args2.key = input("请输入音频key：")
    args2.title = args1.title + '_audio'

    m3u8download(args1)
    m3u8download(args2)

    merge.merge_video_audio(video_dir=f'{args1.work_dir + "/" + args1.title + "_de.mp4"}',audio_dir=f'{args2.work_dir + "/" + args2.title + "_de.mp4"}',output_dir=f'{args1.work_dir + "/" + args1.title + ".mp4"}')

if __name__ == '__main__':
    while True:
        run()